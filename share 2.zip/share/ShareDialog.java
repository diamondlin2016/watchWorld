package com.kdx.loho.ui.widget;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomSheetDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import com.kdx.loho.R;
import com.kdx.loho.baselibrary.utils.ToastHelper;
import com.kdx.loho.presenter.SharePresenter;
import com.kdx.net.params.ShareParams;
import com.umeng.socialize.ShareAction;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Author:    Diamond_Lin
 * Version    V1.0
 * Date:      2017/8/1 下午4:36
 * Description:
 * Modification  History:
 * Date         	Author        		Version        	Description
 * -----------------------------------------------------------------------------------
 * 2017/8/1      Diamond_Lin            1.0                    1.0
 * Why & What is modified:
 */

public class ShareDialog implements SharePresenter.OnShareListener {
    @BindView(R.id.tv_wechat)
    TextView mTvWechat;
    @BindView(R.id.tv_moment)
    TextView mTvMoment;
    @BindView(R.id.tv_sina)
    TextView mTvSina;

    private Activity mContext;
    private BottomSheetDialog mBottomSheetDialog;
    private ShareParams mParams;
    private ShareAction mShareAction;
    private SharePresenter mPresenter;

    public static ShareDialog builder(Activity context, @NonNull ShareParams params) {
        return new ShareDialog(context, params);
    }


    public void showDialog() {
        if (!mBottomSheetDialog.isShowing()) {
            mBottomSheetDialog.show();
        }
    }

    @OnClick(R.id.tv_wechat)
    void shareToWeChat() {
        mPresenter.doShare(SharePresenter.WECHAT, mParams, mContext);
        mBottomSheetDialog.dismiss();
    }

    @OnClick(R.id.tv_moment)
    void shareToMoment() {
        mPresenter.doShare(SharePresenter.WECHATMOMENTS, mParams, mContext);
        mBottomSheetDialog.dismiss();
    }

    @OnClick(R.id.tv_sina)
    void shareToWeSina() {
        mPresenter.doShare(SharePresenter.SINA, mParams, mContext);
        mBottomSheetDialog.dismiss();
    }

    @OnClick(R.id.tv_cancel)
    void cancel() {
        mBottomSheetDialog.dismiss();
    }


    private ShareDialog(@NonNull Activity context, ShareParams params) {
        mContext = context;
        View rootView = LayoutInflater.from(context).inflate(R.layout.dialog_share, null, false);
        ButterKnife.bind(this, rootView);
        mBottomSheetDialog = new BottomSheetDialog(context);
        mBottomSheetDialog.setContentView(rootView);
//        mBottomSheetDialog.setCancelable(false);
        mBottomSheetDialog.setCanceledOnTouchOutside(true);
        mPresenter = new SharePresenter(this);
        mParams = params;
        mShareAction = new ShareAction(context);
    }

    @Override
    public void onSuccess() {
        ToastHelper.showToastMessage("分享成功");
        onDestroy();
    }

    @Override
    public void onFail(String message) {
        ToastHelper.showToastMessage(message);
        onDestroy();
    }

    private void onDestroy() {
        mBottomSheetDialog = null;
        mContext = null;
        mParams = null;
        mShareAction = null;
    }
}
