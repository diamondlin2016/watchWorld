package com.kdx.net.params;

import android.graphics.Bitmap;
import android.support.annotation.IntDef;

import com.kdx.net.bean.base.BaseBean;

/**
 * Author:    Diamond_Lin
 * Version    V1.0
 * Date:      2017/8/1 下午5:55
 * Description:
 * Modification  History:
 * Date         	Author        		Version        	Description
 * -----------------------------------------------------------------------------------
 * 2017/8/1      Diamond_Lin            1.0                    1.0
 * Why & What is modified:
 */

public class ShareParams extends BaseBean {
    public static final int TYPE_TEXT = 1;//文本
    public static final int TYPE_IMAGE = 2;//图片
    public static final int TYPE_WEB = 3;//web
    public static final int TYPE_VIDEO = 4;//视频
    public static final int TYPE_MUSIC = 5;//音乐
    public static final int TYPE_GIF = 6;//gif
    public Bitmap mBitmap;//分享本地图片

    @IntDef({TYPE_TEXT, TYPE_IMAGE, TYPE_WEB,TYPE_VIDEO,TYPE_MUSIC,TYPE_GIF})
    @interface ShareType {
    }

    public int type;//分享类型
    public String title;//标题
    public String url;//超链接
    public String image;//图片
    public String thumbImage;//缩略图片
    public String description;//描述
    public String musicUrl;//音乐播放链接

    private ShareParams(@ShareType int type){
        this.type = type;
    }

    public static class Build{
        /*
        * @params text 文字分享内容
        *
        * */
        public static ShareParams buildTextParams(String text){
            ShareParams shareParams = new ShareParams(TYPE_TEXT);
            shareParams.title = text;
            return shareParams;
        }

        /*
        * @params imageUrl 图片分享链接
        *
        * */
        public static ShareParams buildImageParams(String imageUrl){
            ShareParams shareParams = new ShareParams(TYPE_IMAGE);
            shareParams.image = imageUrl;
            return shareParams;
        }

        /*
        * @params file 分享本地图片文件
        *
        * */
        public static ShareParams buildImageParams(Bitmap bitmap){
            ShareParams shareParams = new ShareParams(TYPE_IMAGE);
            shareParams.mBitmap = bitmap;
            return shareParams;
        }

        /*
        * @params webUrl 分享网址
        * @params title 分享标题
        * @params thumbUrl 分享缩略图
        * @params description 分享描述
        *
        * */
        public static ShareParams buildWebParams(String webUrl,String title,String thumbUrl,String description){
            ShareParams shareParams = new ShareParams(TYPE_WEB);
            shareParams.url = webUrl;
            shareParams.title = title;
            shareParams.thumbImage = thumbUrl;
            shareParams.description = description;
            return shareParams;
        }

        /*
        * @params videoUrl 视频分享url
        * @params title 分享title
        * @params thumbUrl 分享缩略图
        * @params description 分享描述
        *
        * */
        public static ShareParams buildVideoParams(String videoUrl,String title,String thumbUrl,String description){
            ShareParams shareParams = new ShareParams(TYPE_VIDEO);
            shareParams.url = videoUrl;
            shareParams.title = title;
            shareParams.thumbImage = thumbUrl;
            shareParams.description = description;
            return shareParams;
        }

        /*
        * @params musicUrl 音乐文件 url
        * @params title 分享title
        * @params thumbUrl 分享缩略图
        * @params description 分享描述
        * @params targetUrl 跳转 url
        *
        * */
        public static ShareParams buildMusicParams(String musicUrl,String title,String thumbUrl,String targetUrl){
            ShareParams shareParams = new ShareParams(TYPE_MUSIC);
            shareParams.url = targetUrl;
            shareParams.title = title;
            shareParams.thumbImage = thumbUrl;
            shareParams.musicUrl = musicUrl;
            return shareParams;
        }

        /*
        * @params gifUrl gif文件 url
        *
        * */
        public static ShareParams buildGifParams(String gifUrl){
            ShareParams shareParams = new ShareParams(TYPE_GIF);
            shareParams.url = gifUrl;
            return shareParams;
        }

    }


}
