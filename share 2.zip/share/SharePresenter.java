package com.kdx.loho.presenter;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.IntDef;

import com.kdx.loho.baselibrary.base.mvp.BasePresenter;
import com.kdx.net.params.ShareParams;
import com.umeng.socialize.ShareAction;
import com.umeng.socialize.UMShareListener;
import com.umeng.socialize.bean.SHARE_MEDIA;
import com.umeng.socialize.media.UMEmoji;
import com.umeng.socialize.media.UMImage;
import com.umeng.socialize.media.UMVideo;
import com.umeng.socialize.media.UMWeb;
import com.umeng.socialize.media.UMusic;

/**
 * Author:    Diamond_Lin
 * Version    V1.0
 * Date:      2017/8/1 下午2:04
 * Description:
 * Modification  History:
 * Date         	Author        		Version        	Description
 * -----------------------------------------------------------------------------------
 * 2017/8/1      Diamond_Lin            1.0                    1.0
 * Why & What is modified:
 */

public class SharePresenter extends BasePresenter implements UMShareListener {

    private final OnShareListener mOnShareListener;
    public final static int WECHAT = 1;
    public final static int WECHATMOMENTS = 2;
    public final static int SINA = 3;

    @IntDef({WECHAT, WECHATMOMENTS, SINA})
    public @interface ShareType {

    }

    public SharePresenter(OnShareListener onShareListener) {
        mOnShareListener = onShareListener;
    }

    public void doShare(@ShareType int shareType, ShareParams params, Activity context) {
        ShareAction shareAction = createShareAction(shareType, params, context);
        shareAction.share();
    }

    private ShareAction createShareAction(int shareType, ShareParams params, Activity context) {
        ShareAction shareAction = new ShareAction(context);
        switch (shareType) {
            case WECHAT:
                shareAction.setPlatform(SHARE_MEDIA.WEIXIN);
                break;
            case WECHATMOMENTS:
                shareAction.setPlatform(SHARE_MEDIA.WEIXIN_CIRCLE);
                break;
            case SINA:
                shareAction.setPlatform(SHARE_MEDIA.SINA);
                break;
        }

        switch (params.type) {
            case ShareParams.TYPE_TEXT:
                initTextParams(shareAction, params, context);
                break;
            case ShareParams.TYPE_IMAGE:
                initImageParams(shareAction, params, context);
                break;
            case ShareParams.TYPE_WEB:
                initWebParams(shareAction, params, context);
                break;
            case ShareParams.TYPE_VIDEO:
                initVideoParams(shareAction, params, context);
                break;
            case ShareParams.TYPE_MUSIC:
                initMusicParams(shareAction, params, context);
                break;
            case ShareParams.TYPE_GIF:
                initGifParams(shareAction, params, context);
                break;
        }
        shareAction.setCallback(this);
        return shareAction;

    }

    private void initTextParams(ShareAction shareAction, ShareParams params, Context context) {
        shareAction.withText(params.title);
    }

    private void initImageParams(ShareAction shareAction, ShareParams params, Context context) {
        UMImage umImage;
        if (params.mBitmap != null) {
            umImage = new UMImage(context, params.mBitmap);
        } else {
            umImage = new UMImage(context, params.image);
        }
        shareAction.withMedia(umImage);
    }

    private void initWebParams(ShareAction shareAction, ShareParams params, Context context) {
        UMWeb web = new UMWeb(params.url);
        web.setTitle(params.title);//标题
        web.setThumb(new UMImage(context, params.thumbImage));  //缩略图
        web.setDescription(params.description);//描述
        shareAction.withMedia(web);
    }

    private void initVideoParams(ShareAction shareAction, ShareParams params, Context context) {
        UMVideo video = new UMVideo(params.url);
        video.setTitle(params.title);//标题
        video.setThumb(new UMImage(context, params.thumbImage));  //缩略图
        video.setDescription(params.description);//描述
        shareAction.withMedia(video);
    }

    private void initMusicParams(ShareAction shareAction, ShareParams params, Context context) {
        UMusic music = new UMusic(params.musicUrl);//音乐的播放链接
        music.setTitle(params.title);//音乐的标题
        music.setThumb(new UMImage(context, params.thumbImage));//音乐的缩略图
        music.setDescription(params.description);//音乐的描述
        music.setmTargetUrl(params.url);//音乐的跳转链接
        shareAction.withMedia(music);
    }

    private void initGifParams(ShareAction shareAction, ShareParams params, Context context) {
        UMEmoji emoji = new UMEmoji(context, params.url);
        emoji.setThumb(new UMImage(context, params.url));
        shareAction.withMedia(emoji);
    }

    @Override
    public void onStart(SHARE_MEDIA share_media) {

    }

    @Override
    public void onResult(SHARE_MEDIA share_media) {
        mOnShareListener.onSuccess();
    }

    @Override
    public void onError(SHARE_MEDIA share_media, Throwable throwable) {
        mOnShareListener.onFail(throwable.getMessage());
    }

    @Override
    public void onCancel(SHARE_MEDIA share_media) {

    }

    public interface OnShareListener {
        void onSuccess(); //成功

        void onFail(String message); //失败

    }
}
